

###### (Automatically generated documentation)

# WhatsHappening

## Description
A measure to figure out what is happening

## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments




This measure does not have any user arguments


